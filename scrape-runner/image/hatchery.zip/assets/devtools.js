import"./modulepreload-polyfill-a574aa36.js";import{j as e}from"./helpers-ba59aadc.js";e().devtools.panels.create("Hatchery","icon.png","index.html");
