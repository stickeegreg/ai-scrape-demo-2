/**
 * Replace the `attachShadow()` function so that all shadow DOMs are 'open',
 * allowing the script to work inside them.
 *
 * @returns {void}
 */
(function () {
    const original = Element.prototype.attachShadow;

    Element.prototype.attachShadow = function (init) {
        init.mode = 'open';
        return original.call(this, init);
    };
})();
