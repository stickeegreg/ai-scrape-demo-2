// This stub is only used in live (extension) mode

/**
 * Get the namespace for the Javascript APIs.
 *
 * The standard namespace is called 'browser', but Chrome calls it 'chrome'.
 *
 * @note This does not polyfill any other incompatibilities.
 *
 * @returns {object} Returns the namespace containing the Javascript APIs.
 */
const getBrowser = function () {
    return typeof browser === 'undefined' ? chrome : browser;
};

/**
 * Inject the shadow DOM override script as a <script> tag.
 *
 * @returns  {void}
 */
const injectOverride = function () {
    const head = document.head || document.documentElement;

    if (!head) {
        return;
    }

    const scriptElement = document.createElement('script');
    scriptElement.src = getBrowser().runtime.getURL('/assets/override-shadow-dom.js');

    head.insertBefore(scriptElement, head.firstChild);
};

window.injectedByExtension = true;
window.loading = new Promise((resolve) => window.addEventListener('load', resolve));

injectOverride();

(async () => {
    console.log('Loading content script...');
    await import('/assets/content-script.js');
    console.log('Loaded content script');
})();
