console.log('Service Worker');

// Things to wait for before a screenshot can be taken.
const screenshotPromises = [];

/**
 * Get a unique ID.
 *
 * @returns {number}
 */
const getId = (() =>
{
    let id = 0;

    return () => --id;
})();

/**
 * A communication link between a content script and a devtools panel,
 * via the service worker.
 *
 * A channel is comprised of two ports, one to the devtools panel and one to the content script.
 * Either port may be opened or closed at any time.  If a message is sent while the port is
 * closed then it will be queued and delivered when the port is open.
 */
class Channel
{
    /**
     * @var {runtime.Port | null} devtoolsPort A connection to a devtools panel.
     */
    devtoolsPort = null;

    /**
     * @var {runtime.Port | null} contentScriptPort A connection to a content script (a tab).
     */
    contentScriptPort = null;

    /**
     * @var {object[]} messagesToDevtools Messages queued to be sent to a devtools panel.
     */
    messagesToDevtools = [];

    /**
     * @var {object[]} messagesToContentScript Messages queued to be sent to a content script.
     */
    messagesToContentScript = [];

    /**
     * @var {number} tabId The ID of the tab for this channel.
     */
    tabId = 0;

    /**
     * @var {Record<string, Function>} handlers Handlers for messages.
     */
    handlers = {};

    /**
     * Create a new channel for a tab.
     *
     * @param {number} tabId The ID of the tab for this channel.
     */
    constructor(tabId)
    {
        this.tabId = tabId;
    }

    /**
     * Set the devtools port.
     *
     * @param {runtime.Port} port The new devtools connection.
     *
     * @returns {void}
     */
    setDevtoolsPort(port)
    {
        this.devtoolsPort = port;

        if (port) {
            // Close the port every so often in an attempt to keep Safari alive
            setTimeout(() => {
                console.log('Closing devtoolsPort');
                port.disconnect();
            }, 290000);

            // Send any pending messages.
            for (const message of this.messagesToDevtools) {
                port.postMessage(message);
            }

            this.messagesToDevtools = [];
        }
    }

    /**
     * Set the content script port.
     *
     * @param {runtime.Port} port The new content script connection.
     *
     * @returns {void}
     */
    setContentScriptPort(port)
    {
        this.contentScriptPort = port;

        if (port) {
            // Close the port every so often in an attempt to keep Safari alive
            setTimeout(() => {
                console.log('Closing contentScriptPort');
                port.disconnect();
            }, 290000);

            // Send any pending messages.
            for (const message of this.messagesToContentScript) {
                port.postMessage(message);
            }

            this.messagesToContentScript = [];
        }
    }

    /**
     * Determine if this channel is connected via the given port.
     *
     * @param {runtime.Port} port The port to find.
     *
     * @returns {boolean} Returns true if the channel uses the given port, false otherwise.
     */
    hasPort(port)
    {
        return this.devtoolsPort === port || this.contentScriptPort === port;
    }

    /**
     * Send a message to the devtools panel.
     *
     * @param {object} message The message to send.
     *
     * @returns {void}
     */
    sendToDevtools(message)
    {
        if (this.devtoolsPort) {
            this.devtoolsPort.postMessage(message);
        } else {
            this.messagesToDevtools.push(message);
        }
    }

    /**
     * Send a message to the devtools panel.
     *
     * @param {object} message the message to send.
     *
     * @returns {void}
     */
    sendToContentScript(message)
    {
        if (this.contentScriptPort) {
            this.contentScriptPort.postMessage(message);
        } else {
            this.messagesToContentScript.push(message);
        }
    }

    /**
     * Register an event handler.
     *
     * @param {string}   event   The name of the event.
     * @param {Function} handler The function to call.
     */
    on(event, handler)
    {
        this.handlers[event] = handler;
    }

    /**
     * Call event handlers for the message.
     *
     * @param {*} message The message to handle.
     *
     * @returns {boolean} Returns true if the message was handled, false if not.
     */
    handle(message)
    {
        if (this.handlers[message.event]) {
            this.handlers[message.event](message);
            return true;
        }

        return false;
    }
};

/**
 * A container for communication channels.
 */
class Channels
{
    /**
     * @var {Channel[]} channels The communication channels.
     */
    channels = [];

    /**
     * Add an incoming connection from a devtools panel.
     *
     * @param {runtime.Port} port  The devtools connection.
     * @param {number}       tabId The ID of the tab for the connection.
     *
     * @returns {void}
     */
    addDevtoolsConnection(port, tabId)
    {
        let channel = this.findByTabId(tabId);

        if (!channel) {
            channel = new Channel(tabId);
            this.channels.push(channel);
        }

        channel.setDevtoolsPort(port);
    }

    /**
     * Add an incoming connection from a content script.
     *
     * @param {runtime.Port} port  The content script connection.
     * @param {number}       tabId The ID of the tab for the connection.
     *
     * @returns {void}
     */
    addContentScriptConnection(port, tabId)
    {
        let channel = this.findByTabId(tabId);

        if (!channel) {
            channel = new Channel(tabId);
            this.channels.push(channel);
        }

        channel.setContentScriptPort(port);
    }

    /**
     * Remove a connection.
     *
     * @param {runtime.Port} port The port to remove.
     *
     * @returns {void}
     */
    close(port)
    {
        const channel = this.findByPort(port);

        if (channel) {
            if (channel.contentScriptPort === port) {
                channel.setContentScriptPort(null);
            } else if (channel.devtoolsPort === port) {
                channel.setDevtoolsPort(null);
            }
        }
    }

    /**
     * Find a channel by looking up an associated port.
     *
     * @param {runtime.Port} port The port to search for.
     *
     * @returns {Channel | undefined} Returns the channel, or undefined if none is found.
     */
    findByPort(port)
    {
        return this.channels.find((channel) => channel.hasPort(port));
    }

    /**
     * Find a channel by looking up an associated tab ID.
     *
     * @param {number} tabId The ID of the tab to search for.
     *
     * @returns {Channel | undefined} Returns the channel, or undefined if none is found.
     */
    findByTabId(tabId)
    {
        return this.channels.find((channel) => channel.tabId === tabId);
    }
};

/**
 * The open communication channels.
 */
const channels = new Channels;

/**
 * Get the namespace for the Javascript APIs.
 *
 * The standard namespace is called 'browser', but Chrome calls it 'chrome'.
 *
 * @note This does not polyfill any other incompatibilities.
 *
 * @returns {object} Returns the namespace containing the Javascript APIs.
 */
const getBrowser = function ()
{
    return typeof browser === 'undefined' ? chrome : browser;
};

/**
 * Delete cookies from the given list of domain names.
 *
 * @param {runtime.Port}         devtoolsPort The port on which to send the reply.
 * @param {ExecuteActionMessage} message      The instruction to clear cookies.
 *
 * @returns {Promise<void>}
 */
const deleteCookies = async function (devtoolsPort, message)
{
    let cookies = [];

    if (message.action.arguments[0].value === '') {
        cookies = await getBrowser().cookies.getAll({});
    } else {
        const domains = message.action.arguments[0].value.split(',').map((h) => h.trim());

        for (const domain of domains) {
            const domainCookies = await getBrowser().cookies.getAll({ domain });

            cookies.push(...domainCookies);
        }
    }

    for (const cookie of cookies) {
        await getBrowser().cookies.remove({
            name: cookie.name,
            url: 'http' + (cookie.secure ? 's' : '') + '://' + cookie.domain.replace(/^\./, '') + cookie.path,
        });
    }

    const response = createMessage('ExecutionResultMessage', message.id);

    response.result = {};
    response.error = null;

    devtoolsPort.postMessage(response);
};

/**
 * Create a message.
 *
 * @param {string} type       The message class name.
 * @param {number} responseId The ID of the message that this is a reply to.
 *
 * @return {object} Returns a new message object.
 */
const createMessage = function (type, responseId)
{
    const message = {
        type: type,
        event: responseId ? 'response-' + responseId : type,
        id: getId(),
        expectsResponse: false,
    };

    return message;
};

/**
 * Create a message instructing the browser to set the scroll bar positions.
 *
 * @param {number} x The horizontal position in CSS pixels.
 * @param {number} y The vertical position in CSS pixels.
 *
 * @returns {ScrollToMessage} Returns a message.
 */
const createScrollToMessage = function (x, y)
{
    const message = createMessage('ScrollToMessage');
    message.expectsResponse = true;
    message.x = x;
    message.y = y;

    return message;
};

/**
 * Capture the visible portion of a tab as a screenshot.
 *
 * This is a wrapper around `browser.tabs.captureVisibleTab()` that
 * adds a delay to prevent triggering the rate limiter.
 *
 * @param {int}          windowId The ID of the window to capture. Defaults to the curren tab.
 * @param {ImageDetails} options  Capture options.
 *
 * @returns {Promise} Returns a promise containing a screenshot.
 */
const captureVisibleTab = async function (windowId = undefined, options = undefined)
{
    // Wait for rate limiting and possibly also scrolling.
    await Promise.allSettled(screenshotPromises);

    const result = await getBrowser().tabs.captureVisibleTab(windowId, options);

    // Remove the expired waits.
    screenshotPromises.length = 0;

    // Add a new wait.
    screenshotPromises.push(new Promise((resolve) => setTimeout(resolve, 510)));

    return result;
};

/**
 * Capture an image of a tab.
 *
 * @param {Port}                                      devtoolsPort The connection to the devtools panel.
 * @param {ScreenshotMessage | PageScreenshotMessage} message      The screenshot message
 *
 * @returns {Promise<void>}
 */
const takeScreenshot = async function (devtoolsPort, message)
{
    const channel = channels.findByPort(devtoolsPort);

    // Forward the message to the content script and await the ScreenshotInfo response.
    const screenshotInfoPromise = new Promise((resolve) => { channel.on(`response-${message.id}`, resolve); });
    channel.sendToContentScript(message);
    const screenshotInfo = await screenshotInfoPromise;

    if (screenshotInfo.type === 'ErrorMessage') {
        throw new Error(screenshotInfo.message);
    }

    const tab = await getBrowser().tabs.get(channel.tabId);

    if (!tab) {
        throw new Error('Failed to find tab for screenshot message, tab ID ' + channel.tabId);
    }

    if (screenshotInfo.screenshotRects.length !== 1) {
        throw new Error('Screenshot currently supports only one screenshot rect');
    }

    const fragmentWidth = screenshotInfo.viewportWidth;
    const fragmentHeight = screenshotInfo.viewportHeight;
    const screenshotRect = screenshotInfo.screenshotRects[0];

    // If the screenshot area is already entirely within the viewport.
    if (
        screenshotInfo.scrollX <= screenshotRect.x
        && screenshotInfo.scrollY <= screenshotRect.y
        && screenshotInfo.scrollX + fragmentWidth >= screenshotRect.x + screenshotRect.width
        && screenshotInfo.scrollY + fragmentHeight >= screenshotRect.y + screenshotRect.height
    ) {
        const screenshotFragmentMessage = createMessage('ScreenshotFragmentMessage');
        screenshotFragmentMessage.x = screenshotInfo.scrollX;
        screenshotFragmentMessage.y = screenshotInfo.scrollY;
        screenshotFragmentMessage.dataUrl = await captureVisibleTab();
        channel.sendToDevtools(screenshotFragmentMessage);
    } else {
        for (let y = 0; y < screenshotInfo.documentHeight; y += fragmentHeight) {
            for (let x = 0; x < screenshotInfo.documentWidth; x += fragmentWidth) {

                // If it doesn't overlap the required area then skip it.
                if (x > screenshotRect.x + screenshotRect.width)
                    continue;

                if (x + fragmentWidth < screenshotRect.x)
                    continue;

                if (y > screenshotRect.y + screenshotRect.height)
                    continue;

                if (y + fragmentHeight < screenshotRect.y)
                    continue;

                // Ensure the viewport is entirely within the document.
                if (x + fragmentWidth > screenshotInfo.documentWidth) {
                    x = Math.max(0, screenshotInfo.documentWidth - fragmentWidth);
                }

                if (y + fragmentHeight > screenshotInfo.documentHeight) {
                    y = Math.max(0, screenshotInfo.documentHeight - fragmentHeight);
                }

                // Scroll the document.
                const scrollToMessage = createScrollToMessage(x, y);
                channel.sendToContentScript(scrollToMessage);

                // Wait until the scroll completes before capturing the tab.
                screenshotPromises.push(new Promise((resolve) => { channel.on(`response-${scrollToMessage.id}`, resolve); }));

                // Send the fragment to devtools.
                const screenshotFragmentMessage = createMessage('ScreenshotFragmentMessage');
                screenshotFragmentMessage.x = x;
                screenshotFragmentMessage.y = y;
                screenshotFragmentMessage.dataUrl = await captureVisibleTab();
                channel.sendToDevtools(screenshotFragmentMessage);
            }
        }

        // Tell the page to scroll back to its original position.
        const restoreScroll = createScrollToMessage(screenshotInfo.scrollX, screenshotInfo.scrollY);
        channel.sendToContentScript(restoreScroll);
    }

    // Tell devtools that all fragments have been sent.
    const response = createMessage('ScreenshotResponseMessage', message.id);
    response.screenshot = {
        x: Math.round(screenshotRect.x),
        y: Math.round(screenshotRect.y),
        width: Math.round(screenshotRect.width),
        height: Math.round(screenshotRect.height),
        dataUrl: '',
        pixelRatio: screenshotInfo.pixelRatio,
    };

    channel.sendToDevtools(response);
};

/**
 * Capture a screenshot of the current viewport.
 *
 * @param {Port}                      devtoolsPort The connection to the devtools panel.
 * @param {ViewportScreenshotMessage} message The message.
 *
 * @returns {Promise<void>}
 */
const takeViewportScreenshot = async function (devtoolsPort, message)
{
    console.log('Taking viewport screenshot');
    const channel = channels.findByPort(devtoolsPort);

    // Forward the message to the content script and await the ScreenshotInfo response.
    const screenshotInfoPromise = new Promise((resolve) => { channel.on(`response-${message.id}`, resolve); });
    channel.sendToContentScript(message);
    const screenshotInfo = await screenshotInfoPromise;

    if (screenshotInfo.type === 'ErrorMessage') {
        throw new Error(screenshotInfo.message);
    }

    const tab = await getBrowser().tabs.get(channel.tabId);

    if (!tab) {
        throw new Error('Failed to find tab for screenshot message, tab ID ' + channel.tabId);
    }

    const screenshotFragmentMessage = createMessage('ScreenshotFragmentMessage');
    screenshotFragmentMessage.x = screenshotInfo.scrollX;
    screenshotFragmentMessage.y = screenshotInfo.scrollY;
    screenshotFragmentMessage.dataUrl = await captureVisibleTab(tab.windowId);
    channel.sendToDevtools(screenshotFragmentMessage);

    // Tell devtools that all fragments have been sent.
    const response = createMessage('ScreenshotResponseMessage', message.id);
    response.screenshot = {
        x: Math.round(screenshotInfo.scrollX),
        y: Math.round(screenshotInfo.scrollY),
        width: Math.round(screenshotInfo.viewportWidth),
        height: Math.round(screenshotInfo.viewportHeight),
        dataUrl: '',
        pixelRatio: screenshotInfo.pixelRatio,
    };
    console.log('Sending viewport screenshot, response');
    channel.sendToDevtools(response);
};

/**
 * Event handler for receiving a message from a devtools panel.
 *
 * Because the devtools port is not associated with a tab ID, it must wait to
 * receive a TabIdMessage to identify it before adding it to a channel.
 *
 * @param {*} message The message received.
 *
 * @returns {void}
 */
const onDevtoolsMessage = async function (devtoolsPort, message)
{
    console.log('Service Worker received message from devtools panel', message);

    if (message.type === 'TabIdMessage') {
        console.log('Adding devtools connection for tab ' + message.tabId);
        channels.addDevtoolsConnection(devtoolsPort, message.tabId);
    } else if (message.type === 'ExecuteActionMessage' && ['deleteCookies', 'clearStorage'].includes(message.action.name)) {
        try {
            switch (message.action.name) {
                case 'deleteCookies':
                    await deleteCookies(devtoolsPort, message);
                    break;

                case 'clearStorage':
                    // This is not supported in Safari yet
                    await getBrowser().browsingData?.removeLocalStorage({});

                    channels.findByPort(devtoolsPort).sendToContentScript(message);
                    break;
            }
        } catch (e) {
            const response = {
                type: 'ExecutionResultMessage',
                event: 'response-' + message.id,
                id: getId(),
                expectsResponse: false,
                result: null,
                error: e.message,
            };

            devtoolsPort.postMessage(response);
        }
    } else if (message.type === 'ResizeMessage') {
        const channel = channels.findByPort(devtoolsPort);

        if (!channel) {
            throw new Error('Failed to find channel for resize message');
        }

        const tab = await getBrowser().tabs.get(channel.tabId);

        if (!tab) {
            throw new Error('Failed to find tab for resize message, tab ID ' + channel.tabId);
        }

        const window = await getBrowser().windows.get(tab.windowId);

        if (!window) {
            throw new Error('Failed to find window for resize message, window ID ' + tab.windowId);
        }

        const borderWidth = window.width - tab.width;
        const borderHeight = window.height - tab.height;

        const updateInfo = {
            width: message.width + borderWidth - 10,
            height: message.height + borderHeight,
            state: "normal",
        };

        getBrowser().windows.update(tab.windowId, updateInfo);

        // Resize twice to make sure that the last resize makes the window bigger
        // in order to work around a bug in Chrome.  If the resize makes the window
        // smaller then the devtools panel will be hidden.
        updateInfo.width += 10;
        setTimeout(() => getBrowser().windows.update(tab.windowId, updateInfo), 100);
    } else if (message.type === 'ScreenshotMessage' || message.type === 'PageScreenshotMessage') {
        try {
            await takeScreenshot(devtoolsPort, message);
        } catch (e) {
            const errorResponse = createMessage('ErrorMessage', message.id);
            errorResponse.message = e.message;
            devtoolsPort.postMessage(errorResponse);
        }
    } else if (message.type === 'ViewportScreenshotMessage') {
        try {
            await takeViewportScreenshot(devtoolsPort, message);
        } catch (e) {
            const errorResponse = createMessage('ErrorMessage', message.id);
            errorResponse.message = e.message;
            devtoolsPort.postMessage(errorResponse);
        }
    } else {
        channels.findByPort(devtoolsPort).sendToContentScript(message);
    }
};

/**
 * Event handler for receiving an incoming connection.
 *
 * @param {Port} port The newly connected port.
 *
 * @returns {void}
 */
const onConnect = function (port)
{
    console.log('service-worker::onConnect(): Incoming connection from ' + port.name + ', tab ' + port.sender?.tab?.id);

    switch (port.name) {
        case 'devtools':
            // Listen for messages from the devtools connection.
            port.onMessage.addListener((message) => onDevtoolsMessage(port, message));
            port.onDisconnect.addListener((port) => channels.close(port));
            break;

        case 'content-script':
            // Listen for messages from the content script connection.
            port.onMessage.addListener(async (message) =>
            {
                console.log('Service Worker received message from content script', message);
                const channel = channels.findByPort(port);

                if (!channel.handle(message)) {
                    channel.sendToDevtools(message);
                }
            });

            port.onDisconnect.addListener((port) => channels.close(port));
            channels.addContentScriptConnection(port, port.sender.tab.id);
            break;

        default:
            throw new Error('Connection from an unknown port: ' + port.name);
    }
};

// Listen for connections from the devtool panels or from tabs.
getBrowser().runtime.onConnect.addListener(onConnect);

// Heartbeat from Chrome documentation prevents Safari from terminating the
// service worker after 8 minutes (420 seconds)
(() => {
    /**
     * Tracks when a service worker was last alive and extends the service worker
     * lifetime by writing the current time to extension storage every 20 seconds.
     * You should still prepare for unexpected termination - for example, if the
     * extension process crashes or your extension is manually stopped at
     * chrome://serviceworker-internals.
     */
    let heartbeatInterval;
    const start = (new Date()).valueOf();

    async function runHeartbeat() {
        await getBrowser().storage.local.set({ 'last-heartbeat': new Date().getTime() });
        const lastHeartbeat = await getLastHeartbeat();
        console.log(`Last heartbeat: ${((new Date()).valueOf() - start) / 1000} seconds - ${lastHeartbeat}`);
    }

    /**
     * Starts the heartbeat interval which keeps the service worker alive. Call
     * this sparingly when you are doing work which requires persistence, and call
     * stopHeartbeat once that work is complete.
     */
    async function startHeartbeat() {
        // Run the heartbeat once at service worker startup.
        runHeartbeat().then(() => {
            // Then again every 20 seconds.
            heartbeatInterval = setInterval(runHeartbeat, 20 * 1000);
        });
    }

    async function stopHeartbeat() {
        clearInterval(heartbeatInterval);
    }

    /**
     * Returns the last heartbeat stored in extension storage, or undefined if
     * the heartbeat has never run before.
     */
    async function getLastHeartbeat() {
        return (await getBrowser().storage.local.get('last-heartbeat'))['last-heartbeat'];
    }

    startHeartbeat();
})();

getBrowser().commands.onCommand.addListener((command) => {
    console.log(`Command: ${command}`);
});
